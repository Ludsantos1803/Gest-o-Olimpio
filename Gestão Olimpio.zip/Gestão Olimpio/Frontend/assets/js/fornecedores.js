// ==============================================
// Script: fornecedores.js
// Função: Gerenciar o CRUD de fornecedores
// ==============================================

document.addEventListener("DOMContentLoaded", () => {

  // Referências dos elementos HTML
  const formFornecedor = document.getElementById("formFornecedor");
  const tabelaFornecedores = document.getElementById("tabelaFornecedores");
  const logoutBtn = document.getElementById("logoutBtn");

  // ==============================================
  // LOGOUT - limpa o token e volta ao login
  // ==============================================
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "index.html";
  });

  // ==============================================
  // FUNÇÃO: carregar fornecedores do backend
  // ==============================================
  async function carregarFornecedores() {
    const response = await fetch("http://localhost:3000/fornecedores");
    const fornecedores = await response.json();

    tabelaFornecedores.innerHTML = ""; // limpa antes de preencher

    fornecedores.forEach((fornecedor) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="py-2">${fornecedor.empresa}</td>
        <td class="py-2">${fornecedor.cnpj}</td>
        <td class="py-2">${fornecedor.telefone}</td>
        <td class="py-2">${fornecedor.email}</td>
        <td class="py-2">${fornecedor.endereco}</td>
        <td class="py-2 text-center">
          <button class="btn-neon px-2 py-1" onclick="excluirFornecedor(${fornecedor.id})">Excluir</button>
        </td>
      `;
      tabelaFornecedores.appendChild(row);
    });
  }

  // ==============================================
  // FUNÇÃO: adicionar novo fornecedor
  // ==============================================
  formFornecedor.addEventListener("submit", async (e) => {
    e.preventDefault();

    const novoFornecedor = {
      empresa: document.getElementById("empresa").value,
      cnpj: document.getElementById("cnpj").value,
      telefone: document.getElementById("telefone").value,
      email: document.getElementById("email").value,
      endereco: document.getElementById("endereco").value,
    };

    const response = await fetch("http://localhost:3000/fornecedores", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novoFornecedor),
    });

    const data = await response.json();

    if (data.success) {
      alert("Fornecedor adicionado com sucesso!");
      formFornecedor.reset();
      carregarFornecedores();
    } else {
      alert("Erro ao adicionar fornecedor!");
    }
  });

  // ==============================================
  // FUNÇÃO: excluir fornecedor
  // ==============================================
  window.excluirFornecedor = async (id) => {
    if (confirm("Deseja realmente excluir este fornecedor?")) {
      const response = await fetch(`http://localhost:3000/fornecedores/${id}`, {
        method: "DELETE",
      });
      const data = await response.json();
      if (data.success) carregarFornecedores();
    }
  };

  // ==============================================
  // Ao carregar a página, buscar todos os fornecedores
  // ==============================================
  carregarFornecedores();
});
