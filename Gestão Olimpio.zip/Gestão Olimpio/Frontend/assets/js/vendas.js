// ========================================================
// Script: vendas.js
// Função: Gerenciar vendas, atualizar estoque e listar vendas
// ========================================================

document.addEventListener("DOMContentLoaded", () => {

  const formVenda = document.getElementById("formVenda");
  const tabelaVendas = document.getElementById("tabelaVendas");
  const clienteSelect = document.getElementById("cliente");
  const produtoSelect = document.getElementById("produto");
  const logoutBtn = document.getElementById("logoutBtn");

  // ========================================================
  // LOGOUT
  // ========================================================
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "index.html";
  });

  // ========================================================
  // Carregar clientes no select
  // ========================================================
  async function carregarClientes() {
    const response = await fetch("http://localhost:3000/clientes");
    const clientes = await response.json();

    clienteSelect.innerHTML = '<option value="">Selecione o cliente</option>';
    clientes.forEach(c => {
      const option = document.createElement("option");
      option.value = c.id;
      option.textContent = c.nome;
      clienteSelect.appendChild(option);
    });
  }

  // ========================================================
  // Carregar produtos no select
  // ========================================================
  async function carregarProdutos() {
    const response = await fetch("http://localhost:3000/produtos");
    const produtos = await response.json();

    produtoSelect.innerHTML = '<option value="">Selecione o produto</option>';
    produtos.forEach(p => {
      const option = document.createElement("option");
      option.value = p.id;
      option.textContent = `${p.nome} - Estoque: ${p.estoque}`;
      produtoSelect.appendChild(option);
    });
  }

  // ========================================================
  // Carregar vendas
  // ========================================================
  async function carregarVendas() {
    const response = await fetch("http://localhost:3000/vendas");
    const vendas = await response.json();

    tabelaVendas.innerHTML = "";

    vendas.forEach(venda => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="py-2">${venda.cliente_nome}</td>
        <td class="py-2">${venda.produto_nome}</td>
        <td class="py-2">${venda.quantidade}</td>
        <td class="py-2">R$ ${parseFloat(venda.valor_total).toFixed(2)}</td>
        <td class="py-2 text-center">
          <button class="btn-neon px-2 py-1" onclick="excluirVenda(${venda.id})">Excluir</button>
        </td>
      `;
      tabelaVendas.appendChild(row);
    });
  }

  // ========================================================
  // Registrar nova venda
  // ========================================================
  formVenda.addEventListener("submit", async (e) => {
    e.preventDefault();

    const venda = {
      cliente_id: parseInt(clienteSelect.value),
      produto_id: parseInt(produtoSelect.value),
      quantidade: parseInt(document.getElementById("quantidade").value)
    };

    const response = await fetch("http://localhost:3000/vendas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(venda)
    });

    const data = await response.json();

    if (data.success) {
      alert("Venda registrada com sucesso!");
      formVenda.reset();
      carregarVendas();
      carregarProdutos(); // atualizar estoque
    } else {
      alert("Erro ao registrar venda: " + data.message);
    }
  });

  // ========================================================
  // Excluir venda
  // ========================================================
  window.excluirVenda = async (id) => {
    if (confirm("Deseja realmente excluir esta venda?")) {
      const response = await fetch(`http://localhost:3000/vendas/${id}`, {
        method: "DELETE"
      });
      const data = await response.json();
      if (data.success) {
        carregarVendas();
        carregarProdutos();
      }
    }
  };

  // ========================================================
  // Inicialização
  // ========================================================
  carregarClientes();
  carregarProdutos();
  carregarVendas();

});
