// ========================================================
// Script: produtos.js
// Função: Gerenciar o CRUD de produtos
// ========================================================

document.addEventListener("DOMContentLoaded", () => {

  // Referências dos elementos
  const formProduto = document.getElementById("formProduto");
  const tabelaProdutos = document.getElementById("tabelaProdutos");
  const fornecedorSelect = document.getElementById("fornecedor");
  const logoutBtn = document.getElementById("logoutBtn");

  // ========================================================
  // LOGOUT
  // ========================================================
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "index.html";
  });

  // ========================================================
  // FUNÇÃO: Carregar fornecedores (para o select)
  // ========================================================
  async function carregarFornecedores() {
    const response = await fetch("http://localhost:3000/fornecedores");
    const fornecedores = await response.json();

    fornecedorSelect.innerHTML = '<option value="">Selecione o fornecedor</option>';
    fornecedores.forEach((f) => {
      const option = document.createElement("option");
      option.value = f.id;
      option.textContent = f.nome;
      fornecedorSelect.appendChild(option);
    });
  }

  // ========================================================
  // FUNÇÃO: Carregar produtos
  // ========================================================
  async function carregarProdutos() {
    const response = await fetch("http://localhost:3000/produtos");
    const produtos = await response.json();

    tabelaProdutos.innerHTML = "";

    produtos.forEach((produto) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="py-2">${produto.nome}</td>
        <td class="py-2">${produto.codigo}</td>
        <td class="py-2">R$ ${parseFloat(produto.preco).toFixed(2)}</td>
        <td class="py-2">${produto.estoque}</td>
        <td class="py-2">${produto.fornecedor_nome || "—"}</td>
        <td class="py-2 text-center">
          <button class="btn-neon px-2 py-1" onclick="excluirProduto(${produto.id})">Excluir</button>
        </td>
      `;
      tabelaProdutos.appendChild(row);
    });
  }

  // ========================================================
  // FUNÇÃO: Adicionar produto
  // ========================================================
  formProduto.addEventListener("submit", async (e) => {
    e.preventDefault();

    const novoProduto = {
      nome: document.getElementById("nome").value,
      codigo: document.getElementById("codigo").value,
      preco: parseFloat(document.getElementById("preco").value),
      estoque: parseInt(document.getElementById("estoque").value),
      fornecedor_id: parseInt(document.getElementById("fornecedor").value),
    };

    const response = await fetch("http://localhost:3000/produtos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novoProduto),
    });

    const data = await response.json();

    if (data.success) {
      alert("Produto adicionado com sucesso!");
      formProduto.reset();
      carregarProdutos();
    } else {
      alert("Erro ao adicionar produto!");
    }
  });

  // ========================================================
  // FUNÇÃO: Excluir produto
  // ========================================================
  window.excluirProduto = async (id) => {
    if (confirm("Deseja realmente excluir este produto?")) {
      const response = await fetch(`http://localhost:3000/produtos/${id}`, {
        method: "DELETE",
      });
      const data = await response.json();
      if (data.success) carregarProdutos();
    }
  };

  // ========================================================
  // Inicialização da página
  // ========================================================
  carregarFornecedores();
  carregarProdutos();
});
