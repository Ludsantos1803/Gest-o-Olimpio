// ========================================================
// Script: clientes.js
// Função: Gerenciar o CRUD de clientes
// ========================================================

document.addEventListener("DOMContentLoaded", () => {

  // Referências dos elementos
  const formCliente = document.getElementById("formCliente");
  const tabelaClientes = document.getElementById("tabelaClientes");
  const logoutBtn = document.getElementById("logoutBtn");

  // ========================================================
  // LOGOUT
  // ========================================================
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "index.html";
  });

  // ========================================================
  // FUNÇÃO: Carregar clientes
  // ========================================================
  async function carregarClientes() {
    const response = await fetch("http://localhost:3000/clientes");
    const clientes = await response.json();

    tabelaClientes.innerHTML = "";

    clientes.forEach((cliente) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="py-2">${cliente.nome}</td>
        <td class="py-2">${cliente.cpfcnpj}</td>
        <td class="py-2">${cliente.telefone}</td>
        <td class="py-2">${cliente.email}</td>
        <td class="py-2">${cliente.cidade}</td>
        <td class="py-2 text-center">
          <button class="btn-neon px-2 py-1" onclick="excluirCliente(${cliente.id})">Excluir</button>
        </td>
      `;
      tabelaClientes.appendChild(row);
    });
  }

  // ========================================================
  // FUNÇÃO: Adicionar cliente
  // ========================================================
  formCliente.addEventListener("submit", async (e) => {
    e.preventDefault();

    const novoCliente = {
      nome: document.getElementById("nome").value,
      cpfcnpj: document.getElementById("cpfcnpj").value,
      telefone: document.getElementById("telefone").value,
      email: document.getElementById("email").value,
      cidade: document.getElementById("cidade").value,
    };

    const response = await fetch("http://localhost:3000/clientes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novoCliente),
    });

    const data = await response.json();

    if (data.success) {
      alert("Cliente adicionado com sucesso!");
      formCliente.reset();
      carregarClientes();
    } else {
      alert("Erro ao adicionar cliente!");
    }
  });

  // ========================================================
  // FUNÇÃO: Excluir cliente
  // ========================================================
  window.excluirCliente = async (id) => {
    if (confirm("Deseja realmente excluir este cliente?")) {
      const response = await fetch(`http://localhost:3000/clientes/${id}`, {
        method: "DELETE",
      });
      const data = await response.json();
      if (data.success) carregarClientes();
    }
  };

  // ========================================================
  // Ao carregar a página, buscar todos os clientes
  // ========================================================
  carregarClientes();
});
